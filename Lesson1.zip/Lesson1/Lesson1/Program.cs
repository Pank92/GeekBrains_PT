﻿//developer Sergey Varnavskoy (Сергей Варнавской)
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Lesson1
{

    class Program
    {
        

        static void Main(string[] args)
        {
            string my_name = "Сергей", my_surname = "Варнавской", my_city = "Ставрополь";

            #region Task1
            Console.Title = ("Анкета");
            Console.Write("Введите имя: ");
            string name = Console.ReadLine();
            Console.Write("Введите фамилию: ");
            string surname = Console.ReadLine();
            Console.Write("Введите свой рост (в метрах): ");
            string height = Console.ReadLine();
            Console.Write("Введите свой вес (в килограммах): ");
            string weight = Console.ReadLine();
            double ht = Convert.ToDouble(height);
            double wt = Convert.ToDouble(weight);

            Console.WriteLine(name + " " + surname + " " + "Рост: " + ht + "М " + "Вес: " + wt + "Кг ");
            Console.WriteLine("{0 } {1 } Рост: {2}М Вес: {3}Кг", name, surname, ht, wt);
            Console.WriteLine($"{name} {surname} Рост: {ht}М Вес: {wt}Кг");
            #endregion
            #region Task2
            Console.WriteLine("Нажмите 'Enter', чтобы узнать ИМТ.");
            Console.Read();
            double imt = wt / Math.Pow(ht, 2);
            Console.WriteLine($"Индекс массы тела равен: {imt:F2}");

            Console.WriteLine("Нажмите 'Enter', чтобы продолжить.");
            Console.ReadLine();
            Console.Read();//костыль! Без него программа не хочет останавливаться в этом месте. Мне очень интересно, почему так?
            #endregion

            #region Task3
            Console.Clear();
            Console.Title = ("Расчет растояния между точками");
            Console.WriteLine("Введите координаты первой точки:");
            Console.Write("X1 = ");
            Console.Read();//Опять костыль. Как от них избавиться?
            string x1_input = Console.ReadLine();
            Console.Write("Y1 = ");
            string y1_input = Console.ReadLine();

            Console.WriteLine("Введите координаты второй точки:");
            Console.Write("X2 = ");
            string x2_input = Console.ReadLine();
            Console.Write("Y2 = ");
            string y2_input = Console.ReadLine();

            double x1, x2, y1, y2;
            x1 = Convert.ToDouble(x1_input);
            x2 = Convert.ToDouble(x2_input);
            y1 = Convert.ToDouble(y1_input);
            y2 = Convert.ToDouble(y2_input);

            Console.Write("Расстояние между заданными точками равно: ");
            Console.WriteLine(calculation(x1, x2, y1, y2));
            Console.WriteLine("Нажмите 'Enter', чтобы продолжить.");
            Console.ReadLine();
            #endregion
            #region Task4
            Console.Clear();
            Console.Title = ("Меняем местами значения переменных");
            Console.WriteLine("Введите значение первой переменной:");
            Console.Write("a = ");

            string a_input = Console.ReadLine();
            Console.WriteLine("Введите значение второй переменной:");
            Console.Write("b = ");
            string b_input = Console.ReadLine();
            int a = Convert.ToInt32(a_input);
            int b = Convert.ToInt32(b_input);
            Console.WriteLine($"Дано: a = {a}, b = {b}");
            Console.WriteLine("Нажмите 'Enter', чтобы поменять местами значения.");
            Console.Read();
            a = a + b;
            b = a - b;
            a = a - b;
            Console.WriteLine($" a = {a}, b = {b}");
            Console.WriteLine("Нажмите 'Enter', чтобы узнать кто автор программы.");
            Console.Read();
            Console.Read();//Опять костыль. Как от них избавиться?
            #endregion
            #region Task5
            Console.Title = ("Информация о разработчике");
            Console.Clear();
            
            
            string message = $"{my_name} {my_surname}. Город {my_city}.";
            string ms_exit = "Нажмите 'Enter', чтобы выйти из программы.";
            int x = (Console.WindowWidth / 2) - (message.Length / 2);
            int x_exit = (Console.WindowWidth / 2) - (ms_exit.Length / 2);
            int y = 1;
            
            Print(x, y, message);
            Print(x_exit, 5, ms_exit);
            Console.Read();
            Console.Read();//Опять костыль. Что я делаю не так?
            #endregion
        }
        static double calculation(double x1, double x2, double y1, double y2)
        {
            return Math.Sqrt(Math.Pow(x2 - x1, 2)) + Math.Pow(y2 - y1, 2);

        }
        static void Print(int x, int y, string ms)
        {
            Console.SetCursorPosition(x, y);
            Console.WriteLine(ms);
        }
    }
}
